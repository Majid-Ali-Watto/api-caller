import "./App.css";
import ApiCallSection from "./components/Api-Call-Section";

function App() {
	return (
		<>
			<ApiCallSection />
		</>
	);
}

export default App;
